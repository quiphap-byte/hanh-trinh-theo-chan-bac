import React, { useState, useEffect } from 'react';
import { 
  ArrowLeft, Check, X, Award, MapPin, Sparkles, BookOpen, Clock, 
  ChevronRight, ChevronUp, ChevronDown, RotateCcw, Volume2 
} from 'lucide-react';
import { Lesson, LessonStep, UserProfile, MatchingPair, TimelineItem } from '../types';
import { playSound } from './AudioEngine';

interface LessonPlayerProps {
  lesson: Lesson;
  steps: LessonStep[];
  currentUser: UserProfile;
  onFinishLesson: (earnedXP: number, correctCount: number, totalQuestions: number) => void;
  onBackToJourney: () => void;
}

export default function LessonPlayer({
  lesson,
  steps,
  currentUser,
  onFinishLesson,
  onBackToJourney
}: LessonPlayerProps) {
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null); // Multiple choice
  const [answered, setAnswered] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  
  // States for matching questions
  const [selectedLeft, setSelectedLeft] = useState<string | null>(null);
  const [selectedRight, setSelectedRight] = useState<string | null>(null);
  const [matchedLeft, setMatchedLeft] = useState<string[]>([]);
  const [matchedRight, setMatchedRight] = useState<string[]>([]);
  const [matchError, setMatchError] = useState<boolean>(false);

  // States for timeline arrangement questions
  const [timelineItems, setTimelineItems] = useState<TimelineItem[]>([]);

  // Analytics
  const [stats, setStats] = useState({
    correctAnswers: 0,
    totalQuestions: 0,
    earnedXP: 0
  });

  const currentStep = steps[currentStepIndex];

  // Initialize specific step states
  useEffect(() => {
    setAnswered(false);
    setSelectedOption(null);
    setIsCorrect(false);
    setSelectedLeft(null);
    setSelectedRight(null);
    setMatchError(false);

    if (currentStep?.type === 'matching' && currentStep.matching_pairs) {
      setMatchedLeft([]);
      setMatchedRight([]);
    }

    if (currentStep?.type === 'arrange_timeline' && currentStep.timeline_items) {
      // Shuffle initially to make sure the user arranges it
      const shuffled = [...currentStep.timeline_items].sort(() => Math.random() - 0.5);
      setTimelineItems(shuffled);
    }
  }, [currentStepIndex, currentStep]);

  if (!currentStep) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] text-center p-6 bg-white rounded-2xl shadow-sm border border-[#F5F0E6]">
        <Clock className="w-16 h-16 text-[#B22222] mb-4 animate-pulse" />
        <p className="text-lg font-bold text-[#1F2937]">Đang tải chương trình học...</p>
      </div>
    );
  }

  // Calculate overall progress bar
  const progressPercent = Math.round(((currentStepIndex + 1) / steps.length) * 100);

  // Handle single choice selection
  const handleSelectOption = (index: number) => {
    if (answered) return;
    setSelectedOption(index);
  };

  // Submit Multiple Choice
  const handleCheckMultipleChoice = () => {
    if (selectedOption === null || answered) return;
    const correct = selectedOption === currentStep.correct_answer;
    setIsCorrect(correct);
    setAnswered(true);
    playSound(correct);

    setStats(prev => ({
      ...prev,
      totalQuestions: prev.totalQuestions + 1,
      correctAnswers: prev.correctAnswers + (correct ? 1 : 0),
      earnedXP: prev.earnedXP + (correct ? (currentStep.points || 5) : 0)
    }));
  };

  // Submit True / False
  const handleCheckTrueFalse = (isSelectedTrue: boolean) => {
    if (answered) return;
    const correct = isSelectedTrue === currentStep.correct_answer;
    setSelectedOption(isSelectedTrue ? 1 : 0);
    setIsCorrect(correct);
    setAnswered(true);
    playSound(correct);

    setStats(prev => ({
      ...prev,
      totalQuestions: prev.totalQuestions + 1,
      correctAnswers: prev.correctAnswers + (correct ? 1 : 0),
      earnedXP: prev.earnedXP + (correct ? (currentStep.points || 5) : 0)
    }));
  };

  // Handle Left matching column click
  const handleLeftClick = (text: string) => {
    if (matchedLeft.includes(text) || answered) return;
    setSelectedLeft(text);
    if (selectedRight) {
      verifyMatch(text, selectedRight);
    }
  };

  // Handle Right matching column click
  const handleRightClick = (text: string) => {
    if (matchedRight.includes(text) || answered) return;
    setSelectedRight(text);
    if (selectedLeft) {
      verifyMatch(selectedLeft, text);
    }
  };

  // Check matching candidate
  const verifyMatch = (leftText: string, rightText: string) => {
    if (!currentStep.matching_pairs) return;
    
    // Find the correct pair index
    const pairIndex = currentStep.matching_pairs.findIndex(
      p => p.left === leftText && p.right === rightText
    );

    if (pairIndex !== -1) {
      // Match correct!
      setMatchedLeft(prev => [...prev, leftText]);
      setMatchedRight(prev => [...prev, rightText]);
      setSelectedLeft(null);
      setSelectedRight(null);
      playSound(true);

      // Check if all matched
      if (matchedLeft.length + 1 === currentStep.matching_pairs.length) {
        setIsCorrect(true);
        setAnswered(true);
        setStats(prev => ({
          ...prev,
          totalQuestions: prev.totalQuestions + 1,
          correctAnswers: prev.correctAnswers + 1,
          earnedXP: prev.earnedXP + (currentStep.points || 10)
        }));
      }
    } else {
      // Wrong match
      setMatchError(true);
      playSound(false);
      setTimeout(() => {
        setSelectedLeft(null);
        setSelectedRight(null);
        setMatchError(false);
      }, 800);
    }
  };

  // Arrange Timeline reordering helper
  const moveItem = (index: number, direction: 'up' | 'down') => {
    if (answered) return;
    const newItems = [...timelineItems];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    
    if (targetIndex < 0 || targetIndex >= newItems.length) return;

    // Swap elements
    const temp = newItems[index];
    newItems[index] = newItems[targetIndex];
    newItems[targetIndex] = temp;
    setTimelineItems(newItems);
  };

  // Verify chronology
  const handleCheckTimelineOrder = () => {
    if (answered) return;
    if (!currentStep.correct_answer) return;

    // Check if the IDs match correct order index
    const expectedOrder = currentStep.correct_answer as string[];
    const currentOrder = timelineItems.map(item => item.id);
    
    const correct = JSON.stringify(currentOrder) === JSON.stringify(expectedOrder);
    setIsCorrect(correct);
    setAnswered(true);
    playSound(correct);

    setStats(prev => ({
      ...prev,
      totalQuestions: prev.totalQuestions + 1,
      correctAnswers: prev.correctAnswers + (correct ? 1 : 0),
      earnedXP: prev.earnedXP + (correct ? (currentStep.points || 10) : 0)
    }));
  };

  // Proceed step or finish lesson
  const handleNextStep = () => {
    // Collect experience from non-quiz standard cards
    let extraXP = 0;
    if (currentStep.type === 'story' || currentStep.type === 'timeline') {
      extraXP = 2; // +2 XP for reading cards
    }

    setStats(prev => ({
      ...prev,
      earnedXP: prev.earnedXP + extraXP
    }));

    if (currentStepIndex + 1 < steps.length) {
      setCurrentStepIndex(prev => prev + 1);
    } else {
      // Completed last step of lesson
      const finalXP = stats.earnedXP + extraXP + (lesson.xp_reward || 20);
      onFinishLesson(finalXP, stats.correctAnswers, stats.totalQuestions);
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto px-4 py-4 md:py-8" id="lesson_player_container">
      {/* Top Header Controls */}
      <div className="flex items-center justify-between mb-6">
        <button 
          onClick={onBackToJourney}
          className="flex items-center gap-1.5 text-sm font-semibold text-[#4A6B57] hover:text-[#B22222] transition-colors"
          id="back_to_journey_btn"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Thoát ra</span>
        </button>

        <div className="flex-1 mx-4">
          <div className="w-full bg-[#E5E7EB] rounded-full h-3 overflow-hidden shadow-inner">
            <div 
              className="bg-[#D4AF37] h-full rounded-full transition-all duration-300"
              style={{ width: `${progressPercent}%` }}
              id="lesson_progress_bar"
            ></div>
          </div>
        </div>

        <span className="text-xs font-bold font-mono text-gray-500 bg-gray-100 px-2 py-1 rounded" id="step_indicator">
          {currentStepIndex + 1}/{steps.length}
        </span>
      </div>

      {/* Active Screen Card */}
      <div className="bg-white rounded-2xl p-5 md:p-8 shadow-md border border-amber-100 h-full flex flex-col justify-between" id="active_step_card">
        <div>
          {/* Tag & Sub-header */}
          <div className="flex items-center justify-between mb-4">
            <span className={`text-xs font-bold uppercase tracking-wider px-2.5 py-1 rounded-full ${
              currentStep.type === 'story' ? 'bg-amber-100 text-[#B22222]' :
              currentStep.type === 'timeline' ? 'bg-blue-100 text-blue-700' :
              'bg-[#F5F0E6] text-[#4A6B57]'
            }`} id="step_type_tag">
              {currentStep.type === 'story' && '⚡ Truyền cảm hứng'}
              {currentStep.type === 'timeline' && '📅 Mốc lịch sử'}
              {currentStep.type === 'multiple_choice' && '🎯 Câu hỏi MCQ'}
              {currentStep.type === 'true_false' && '⚖️ Hỏi nhanh'}
              {currentStep.type === 'matching' && '🧩 Ghép nối địa danh'}
              {currentStep.type === 'arrange_timeline' && '⏳ Thứ tự thời gian'}
            </span>
            
            <button 
              onClick={() => playSound(true)} 
              className="p-1 px-2 text-xs text-[#4A6B57] flex items-center gap-1 hover:bg-gray-100 rounded"
              title="Test âm thanh"
            >
              <Volume2 className="w-4 h-4" /> Nhạc
            </button>
          </div>

          <h2 className="text-xl md:text-2xl font-bold text-[#1F2937] mb-4" id="step_title">
            {currentStep.title}
          </h2>

          {/* RENDERING CONDITIONAL ON STEP TYPE */}
          
          {/* 1. STORY CARD */}
          {currentStep.type === 'story' && (
            <div className="space-y-4 animate-fade-in" id="story_step_content">
              {currentStep.image_url && (
                <div className="w-full h-48 md:h-64 rounded-xl overflow-hidden shadow-sm border border-gray-100">
                  <img 
                    src={currentStep.image_url} 
                    alt={currentStep.title} 
                    className="w-full h-full object-cover transform hover:scale-105 transition-transform duration-700" 
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1599707367072-cd6ada2bc375?auto=format&fit=crop&q=80&w=600';
                    }}
                  />
                </div>
              )}
              <p className="text-gray-700 leading-relaxed text-base md:text-lg bg-amber-50/50 p-4 rounded-xl border-l-4 border-[#B22222] text-justify select-text" id="story_text">
                {currentStep.content}
              </p>
              <div className="text-xs text-slate-400 italic">Chúc mừng! Bạn nhận được +2 EXP sau khi đọc nội dung này.</div>
            </div>
          )}

          {/* 2. TIMELINE FACT */}
          {currentStep.type === 'timeline' && (
            <div className="space-y-4 animate-fade-in" id="timeline_step_content">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-[#B22222]/10 p-4 rounded-xl border border-[#B22222]/20">
                  <span className="text-xs font-bold text-[#B22222] uppercase tracking-wide">Năm diễn ra</span>
                  <p className="text-2xl font-black text-[#B22222]" id="timeline_fact_year">
                    {currentStep.fact_year}
                  </p>
                </div>
                <div className="bg-[#4A6B57]/10 p-4 rounded-xl border border-[#4A6B57]/20">
                  <span className="text-xs font-bold text-[#4A6B57] uppercase tracking-wide">Địa điểm</span>
                  <p className="text-lg font-bold text-[#4A6B57] truncate" id="timeline_fact_location">
                    {currentStep.fact_location}
                  </p>
                </div>
              </div>
              
              <div className="bg-white p-5 rounded-xl border border-gray-100">
                <h4 className="font-bold text-[#1F2937] mb-2 text-sm text-[#D4AF37]">SỰ KIỆN GHI NHỚ KHẮC SÂU</h4>
                <p className="text-gray-700 text-base md:text-lg leading-relaxed font-serif text-justify select-text">
                  {currentStep.content}
                </p>
              </div>
              <div className="text-xs text-slate-500 italic">Đã rèn luyện ghi nhớ cột mốc này. Tương tác tiếp theo sẽ tăng thêm +2 EXP.</div>
            </div>
          )}

          {/* 3. MULTIPLE CHOICE QUESTION */}
          {currentStep.type === 'multiple_choice' && (
            <div className="space-y-4 animate-fade-in" id="multiple_choice_step_content">
              <p className="text-lg font-semibold text-[#1F2937] mb-4 bg-[#F5F0E6]/30 p-3 rounded text-justify select-text" id="question_text">
                {currentStep.question_text}
              </p>

              <div className="grid grid-cols-1 gap-2.5">
                {currentStep.options?.map((option, index) => {
                  let btnStyle = "border-gray-200 hover:bg-gray-50 text-gray-700";
                  
                  if (answered) {
                    if (index === currentStep.correct_answer) {
                      btnStyle = "bg-green-50 border-green-400 text-green-700 font-bold ring-2 ring-green-400";
                    } else if (selectedOption === index) {
                      btnStyle = "bg-red-50 border-red-400 text-red-700 ring-2 ring-red-400";
                    } else {
                      btnStyle = "opacity-50 border-gray-100 text-gray-400";
                    }
                  } else if (selectedOption === index) {
                    btnStyle = "border-[#B22222] bg-[#B22222]/5 text-[#B22222] ring-2 ring-[#B22222]";
                  }

                  return (
                    <button
                      key={index}
                      onClick={() => handleSelectOption(index)}
                      disabled={answered}
                      className={`w-full p-4 text-left rounded-xl border transition-all duration-150 flex items-center justify-between text-base ${btnStyle}`}
                      id={`mcq_option_${index}`}
                    >
                      <span>{option}</span>
                      {answered && index === currentStep.correct_answer && <Check className="w-5 h-5 text-green-600 flex-shrink-0" />}
                      {answered && selectedOption === index && index !== currentStep.correct_answer && <X className="w-5 h-5 text-red-600 flex-shrink-0" />}
                    </button>
                  );
                })}
              </div>

              {!answered && (
                <button
                  onClick={handleCheckMultipleChoice}
                  disabled={selectedOption === null}
                  className={`w-full py-4 rounded-xl font-bold uppercase tracking-wider text-white transition-all ${
                    selectedOption !== null 
                      ? 'bg-[#B22222] hover:bg-red-800' 
                      : 'bg-gray-300 cursor-not-allowed'
                  }`}
                  id="submit_mcq_btn"
                >
                  Kiểm tra câu trả lời (+5 EXP)
                </button>
              )}
            </div>
          )}

          {/* 4. TRUE / FALSE QUESTION */}
          {currentStep.type === 'true_false' && (
            <div className="space-y-4 animate-fade-in" id="true_false_step_content">
              <p className="text-lg font-semibold text-[#1F2937] mb-6 bg-[#F5F0E6]/30 p-3 rounded text-justify select-text" id="true_false_question_text">
                {currentStep.question_text}
              </p>

              <div className="grid grid-cols-2 gap-4">
                {/* ĐÚNG button */}
                <button
                  disabled={answered}
                  onClick={() => handleCheckTrueFalse(true)}
                  className={`py-6 px-4 rounded-2xl flex flex-col items-center justify-center border font-bold text-lg transition-all ${
                    answered ? (
                      currentStep.correct_answer === true
                        ? 'bg-green-50 border-green-500 text-green-700'
                        : (selectedOption === 1 ? 'bg-red-50 border-red-500 text-red-700' : 'opacity-40 border-gray-100')
                    ) : (
                      'border-gray-200 hover:bg-green-50/50 hover:border-green-400 text-gray-700 text-green-600'
                    )
                  }`}
                  id="true_option_btn"
                >
                  <Check className="w-8 h-8 mb-2" />
                  <span>Đúng</span>
                </button>

                {/* SAI button */}
                <button
                  disabled={answered}
                  onClick={() => handleCheckTrueFalse(false)}
                  className={`py-6 px-4 rounded-2xl flex flex-col items-center justify-center border font-bold text-lg transition-all ${
                    answered ? (
                      currentStep.correct_answer === false
                        ? 'bg-green-50 border-green-500 text-green-700'
                        : (selectedOption === 0 ? 'bg-red-50 border-red-500 text-red-700' : 'opacity-40 border-gray-100')
                    ) : (
                      'border-gray-200 hover:bg-red-50/50 hover:border-red-400 text-gray-700 text-red-600'
                    )
                  }`}
                  id="false_option_btn"
                >
                  <X className="w-8 h-8 mb-2" />
                  <span>Sai</span>
                </button>
              </div>
            </div>
          )}

          {/* 5. MATCHING QUESTION */}
          {currentStep.type === 'matching' && currentStep.matching_pairs && (
            <div className="space-y-4 animate-fade-in" id="matching_step_content">
              <p className="text-base text-gray-600 mb-2">
                {currentStep.question_text}
              </p>

              <div className="grid grid-cols-2 gap-2 md:gap-4">
                {/* Column A (Left) */}
                <div className="space-y-2">
                  <h4 className="text-[10px] md:text-xs font-bold uppercase bg-[#B22222]/10 text-[#B22222] p-1.5 rounded text-center">Cột Từ khóa</h4>
                  {currentStep.matching_pairs.map((pair, idx) => {
                    const isMatched = matchedLeft.includes(pair.left);
                    const isSel = selectedLeft === pair.left;
                    
                    return (
                      <button
                        key={idx}
                        onClick={() => handleLeftClick(pair.left)}
                        disabled={isMatched || answered}
                        className={`w-full p-2.5 md:p-3 rounded-lg border text-[10px] xs:text-xs md:text-sm text-left font-black transition-all leading-tight min-h-[44px] ${
                          isMatched 
                            ? 'bg-green-50 border-green-400 text-green-700 cursor-not-allowed line-through' 
                            : isSel 
                              ? 'bg-blue-50 border-blue-500 text-blue-700 ring-2 ring-blue-400 shadow-sm' 
                              : matchError && isSel
                                ? 'bg-red-50 border-red-500 text-red-700 shadow-sm'
                                : 'border-gray-200 hover:bg-[#F5F0E6] text-[#1F2937]'
                        }`}
                        id={`matching_left_${idx}`}
                      >
                        {pair.left}
                      </button>
                    );
                  })}
                </div>

                {/* Column B (Right) */}
                <div className="space-y-2">
                  <h4 className="text-[10px] md:text-xs font-bold uppercase bg-[#4A6B57]/10 text-[#4A6B57] p-1.5 rounded text-center">Ý nghĩa lịch sử</h4>
                  {/* Shuffle right display slightly so they are mixed up */}
                  {currentStep.matching_pairs.map((pair, idx) => {
                    const isMatched = matchedRight.includes(pair.right);
                    const isSel = selectedRight === pair.right;
                    
                    return (
                      <button
                        key={idx}
                        onClick={() => handleRightClick(pair.right)}
                        disabled={isMatched || answered}
                        className={`w-full p-2.5 md:p-3 rounded-lg border text-[10px] xs:text-xs md:text-sm text-left font-medium transition-all leading-tight min-h-[110px] sm:min-h-[44px] text-justify select-text ${
                          isMatched
                            ? 'bg-green-50 border-green-400 text-green-700 cursor-not-allowed line-through'
                            : isSel
                              ? 'bg-blue-50 border-blue-500 text-blue-700 ring-2 ring-blue-400 shadow-sm'
                              : matchError && isSel
                                ? 'bg-red-50 border-red-500 text-red-700 shadow-sm'
                                : 'border-gray-200 hover:bg-[#F5F0E6] text-[#1F2937]'
                        }`}
                        id={`matching_right_${idx}`}
                      >
                        {pair.right}
                      </button>
                    );
                  })}
                </div>
              </div>

              {matchError && (
                <p className="text-xs text-center text-red-500 font-semibold animate-pulse">Các cặp ghép không trùng khớp! Hãy chọn lại cặp khác.</p>
              )}
              {matchedLeft.length > 0 && matchedLeft.length < currentStep.matching_pairs.length && (
                <p className="text-xs text-center text-teal-600 font-bold">Đã ghép thành công {matchedLeft.length}/{currentStep.matching_pairs.length} cặp!</p>
              )}
            </div>
          )}

          {/* 6. ARRANGE TIMELINE QUESTION */}
          {currentStep.type === 'arrange_timeline' && (
            <div className="space-y-4 animate-fade-in" id="timeline_arr_step_content">
              <p className="text-base text-gray-600 mb-2">
                {currentStep.question_text}
              </p>

              <div className="space-y-2">
                {timelineItems.map((item, index) => {
                  return (
                    <div
                      key={item.id}
                      className="flex items-center gap-2 p-3.5 bg-[#F5F0E6]/20 border border-amber-200/50 rounded-xl"
                      id={`timeline_item_order_${index}`}
                    >
                      <div className="flex flex-col gap-1">
                        <button
                          onClick={() => moveItem(index, 'up')}
                          disabled={index === 0 || answered}
                          className="p-1 rounded hover:bg-gray-100 disabled:opacity-25"
                          title="Di chuyển lên"
                        >
                          <ChevronUp className="w-4 h-4 text-gray-600" />
                        </button>
                        <button
                          onClick={() => moveItem(index, 'down')}
                          disabled={index === timelineItems.length - 1 || answered}
                          className="p-1 rounded hover:bg-gray-100 disabled:opacity-25"
                          title="Di chuyển xuống"
                        >
                          <ChevronDown className="w-4 h-4 text-gray-600" />
                        </button>
                      </div>

                      <div className="bg-[#B22222] text-[#D4AF37] font-bold font-mono px-2.5 py-1 text-xs rounded">
                        Mốc {index + 1}
                      </div>

                      <div className="flex-1 text-sm text-[#1F2937]">
                        <span className="font-bold font-mono block text-amber-800 text-xs">{item.year}</span>
                        <span>{item.text}</span>
                      </div>
                    </div>
                  );
                })}
              </div>

              {!answered && (
                <button
                  onClick={handleCheckTimelineOrder}
                  className="w-full mt-4 py-3.5 rounded-xl bg-[#4A6B57] hover:bg-[#3d5948] text-white font-bold uppercase text-sm tracking-wide"
                  id="verify_timeline_order_btn"
                >
                  Xác nhận thứ tự các mốc lịch sử (+10 EXP)
                </button>
              )}
            </div>
          )}

          {/* FEEDBACK & EXPLANATION ON ANSWER COMPLETE */}
          {answered && (
            <div className={`mt-6 p-4 rounded-xl border animate-scale-up ${
              isCorrect 
                ? 'bg-light-green bg-green-50 border-green-200' 
                : 'bg-red-50 border-red-200'
            }`} id="explanation_panel">
              <div className="flex items-start gap-3">
                <div className={`p-2 rounded-full ${isCorrect ? 'bg-green-100' : 'bg-red-100'}`}>
                  {isCorrect 
                    ? <Check className="w-5 h-5 text-green-700" /> 
                    : <X className="w-5 h-5 text-red-700" />
                  }
                </div>
                <div>
                  <h4 className={`font-black text-sm ${isCorrect ? 'text-green-800' : 'text-red-800'}`}>
                    {isCorrect ? 'ĐÁP ÁN HOÀN TOÀN CHÍNH XÁC 🎉' : 'CHƯA CHÍNH XÁC RỒI 💡'}
                  </h4>
                  {currentStep.explanation && (
                    <p className="text-sm mt-1.5 text-gray-700 leading-relaxed text-justify select-text">
                      {currentStep.explanation}
                    </p>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Action Next Step Button */}
        <div className="mt-8 flex justify-end" id="action_footer_player">
          {(answered || currentStep.type === 'story' || currentStep.type === 'timeline') && (
            <button
              onClick={handleNextStep}
              className="px-8 py-3.5 rounded-xl font-bold text-white bg-[#B22222] hover:bg-amber-900 transition-colors shadow flex items-center gap-2"
              id="player_next_step_btn"
            >
              <span>{currentStepIndex + 1 < steps.length ? 'Tiếp tục' : 'Hoàn thành bài học 🏆'}</span>
              <ChevronRight className="w-5 h-5" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
