import React, { useState } from 'react';
import { 
  Plus, Edit2, Trash2, RotateCcw, AlertTriangle, ShieldCheck, 
  Users, BookOpen, Layers, BarChart2, Star, Check, X, ShieldAlert 
} from 'lucide-react';
import { Chapter, Lesson, LessonStep, UserProfile, Badge } from '../types';

interface AdminPanelProps {
  chapters: Chapter[];
  lessons: Lesson[];
  steps: LessonStep[];
  profiles: UserProfile[];
  badges: Badge[];
  onResetDb: () => void;
  onUpdateChapters: (newChapters: Chapter[]) => void;
  onUpdateLessons: (newLessons: Lesson[]) => void;
  onUpdateSteps: (newSteps: LessonStep[]) => void;
  onUpdateProfiles: (newProfiles: UserProfile[]) => void;
  onSwitchUser: (userId: string) => void;
}

export default function AdminPanel({
  chapters,
  lessons,
  steps,
  profiles,
  badges,
  onResetDb,
  onUpdateChapters,
  onUpdateLessons,
  onUpdateSteps,
  onUpdateProfiles,
  onSwitchUser
}: AdminPanelProps) {
  const [activeSubTab, setActiveSubTab] = useState<'stats' | 'chapters' | 'lessons' | 'users'>('stats');
  
  // Chapter Form States
  const [editingChapterId, setEditingChapterId] = useState<string | null>(null);
  const [chapterForm, setChapterForm] = useState({
    title: '',
    subtitle: '',
    description: '',
    location: '',
    cover_image: ''
  });

  // Lesson Form States
  const [editingLessonId, setEditingLessonId] = useState<string | null>(null);
  const [lessonForm, setLessonForm] = useState({
    title: '',
    description: '',
    chapter_id: '',
    xp_reward: '20'
  });

  // Stats calculation
  const totalUsers = profiles.length;
  const adminCount = profiles.filter(p => p.role === 'admin').length;
  const totalXP = profiles.reduce((sum, p) => sum + p.xp, 0);
  const totalLessons = lessons.length;
  const activeLessons = lessons.filter(l => l.is_active).length;

  // Chapter CRUD
  const handleSaveChapter = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chapterForm.title || !chapterForm.location) return;

    if (editingChapterId) {
      // Edit
      const updated = chapters.map(c => {
        if (c.id === editingChapterId) {
          return {
            ...c,
            title: chapterForm.title,
            subtitle: chapterForm.subtitle,
            description: chapterForm.description,
            location: chapterForm.location,
            cover_image: chapterForm.cover_image || 'https://images.unsplash.com/photo-1621252179027-94459d278660?auto=format&fit=crop&q=80&w=400'
          };
        }
        return c;
      });
      onUpdateChapters(updated);
      setEditingChapterId(null);
    } else {
      // Add new
      const newCh: Chapter = {
        id: `chapter-${Date.now()}`,
        title: chapterForm.title,
        subtitle: chapterForm.subtitle,
        description: chapterForm.description,
        location: chapterForm.location,
        cover_image: chapterForm.cover_image || 'https://images.unsplash.com/photo-1621252179027-94459d278660?auto=format&fit=crop&q=80&w=400',
        badge_id: 'badge-1', // default badge placeholder
        order_index: chapters.length + 1,
        is_active: true,
        topic_id: 'topic-ho-chi-minh-career' // Default theme topic
      };
      onUpdateChapters([...chapters, newCh]);
    }

    setChapterForm({ title: '', subtitle: '', description: '', location: '', cover_image: '' });
  };

  const startEditChapter = (ch: Chapter) => {
    setEditingChapterId(ch.id);
    setChapterForm({
      title: ch.title,
      subtitle: ch.subtitle || '',
      description: ch.description || '',
      location: ch.location,
      cover_image: ch.cover_image || ''
    });
  };

  const handleDeleteChapter = (id: string) => {
    if (confirm('Bạn có chắc chắn muốn xóa Chương này? Toàn bộ Bài học đi kèm có thể bị ảnh hưởng.')) {
      onUpdateChapters(chapters.filter(c => c.id !== id));
      onUpdateLessons(lessons.filter(l => l.chapter_id !== id));
    }
  };

  // Lesson CRUD
  const handleSaveLesson = (e: React.FormEvent) => {
    e.preventDefault();
    if (!lessonForm.title || !lessonForm.chapter_id) return;

    if (editingLessonId) {
      const updated = lessons.map(l => {
        if (l.id === editingLessonId) {
          return {
            ...l,
            title: lessonForm.title,
            description: lessonForm.description,
            chapter_id: lessonForm.chapter_id,
            xp_reward: parseInt(lessonForm.xp_reward) || 20
          };
        }
        return l;
      });
      onUpdateLessons(updated);
      setEditingLessonId(null);
    } else {
      const newLes: Lesson = {
        id: `lesson-${Date.now()}`,
        chapter_id: lessonForm.chapter_id,
        title: lessonForm.title,
        description: lessonForm.description,
        cover_image: 'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?auto=format&fit=crop&q=80&w=400',
        order_index: lessons.filter(l => l.chapter_id === lessonForm.chapter_id).length + 1,
        xp_reward: parseInt(lessonForm.xp_reward) || 20,
        is_active: true
      };
      onUpdateLessons([...lessons, newLes]);
    }

    setLessonForm({ title: '', description: '', chapter_id: '', xp_reward: '20' });
  };

  const startEditLesson = (les: Lesson) => {
    setEditingLessonId(les.id);
    setLessonForm({
      title: les.title,
      description: les.description || '',
      chapter_id: les.chapter_id,
      xp_reward: les.xp_reward.toString()
    });
  };

  const handleDeleteLesson = (id: string) => {
    if (confirm('Bạn có chắc muốn xóa Bài học này?')) {
      onUpdateLessons(lessons.filter(l => l.id !== id));
    }
  };

  // Profile management and role toggling
  const handleToggleAdmin = (pId: string) => {
    const updated = profiles.map(p => {
      if (p.id === pId) {
        return {
          ...p,
          role: (p.role === 'admin' ? 'member' : 'admin') as any
        };
      }
      return p;
    });
    onUpdateProfiles(updated);
  };

  const handleGiveXP = (pId: string, amount: number) => {
    const updated = profiles.map(p => {
      if (p.id === pId) {
        return {
          ...p,
          xp: p.xp + amount
        };
      }
      return p;
    });
    onUpdateProfiles(updated);
  };

  return (
    <div className="w-full bg-white rounded-2xl shadow-sm border border-amber-100 p-5 md:p-8" id="admin_panel_section">
      {/* Title & Warning Reset */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8 pb-5 border-b border-gray-100">
        <div>
          <span className="flex items-center gap-1.5 text-[#B22222] text-xs font-extrabold uppercase bg-red-50 px-2.5 py-1 rounded inline-flex mb-1.5">
            <ShieldAlert className="w-3.5 h-3.5" /> Chế độ quản trị viên (Admin)
          </span>
          <h2 className="text-xl md:text-2xl font-black text-[#1F2937]">Quản Lý Hệ Thống Bài Học</h2>
          <p className="text-sm text-gray-500">Giúp điều hướng chương trình học Dĩ An, thay đổi thông số game hóa hoặc khởi tạo lại.</p>
        </div>

        <button 
          onClick={() => {
            if (confirm('BẠN CÓ CHẮC MUỐN KHÔI PHỤC TOÀN BỘ CƠ SỞ DỮ LIỆU? Tất cả các bài viết tự thêm mới, huy hiệu và tiến độ đang chơi sẽ quay lại trạng thái mặc định ban đầu.')) {
              onResetDb();
            }
          }}
          className="flex items-center gap-1 text-xs text-[#B22222] font-semibold border border-[#B22222]/20 hover:bg-red-50 px-3.5 py-2.5 rounded-lg transition-all"
          id="reset_database_btn"
        >
          <RotateCcw className="w-4 h-4" /> Reset Database Sạch
        </button>
      </div>

      {/* Sub Tabs Navigation */}
      <div className="flex items-center gap-2 mb-6 border-b border-gray-100 pb-2 overflow-x-auto whitespace-nowrap" id="admin_subtabs">
        <button
          onClick={() => setActiveSubTab('stats')}
          className={`px-4 py-2 rounded-lg text-sm font-bold transition-all flex items-center gap-1.5 ${
            activeSubTab === 'stats' ? 'bg-[#4A6B57] text-white' : 'text-gray-600 hover:bg-gray-100'
          }`}
        >
          <BarChart2 className="w-4 h-4" /> Thống kê chung
        </button>
        <button
          onClick={() => setActiveSubTab('chapters')}
          className={`px-4 py-2 rounded-lg text-sm font-bold transition-all flex items-center gap-1.5 ${
            activeSubTab === 'chapters' ? 'bg-[#4A6B57] text-white' : 'text-gray-600 hover:bg-gray-100'
          }`}
        >
          <Layers className="w-4 h-4" /> Chương học ({chapters.length})
        </button>
        <button
          onClick={() => setActiveSubTab('lessons')}
          className={`px-4 py-2 rounded-lg text-sm font-bold transition-all flex items-center gap-1.5 ${
            activeSubTab === 'lessons' ? 'bg-[#4A6B57] text-white' : 'text-gray-600 hover:bg-gray-100'
          }`}
        >
          <BookOpen className="w-4 h-4" /> Bài học ({lessons.length})
        </button>
        <button
          onClick={() => setActiveSubTab('users')}
          className={`px-4 py-2 rounded-lg text-sm font-bold transition-all flex items-center gap-1.5 ${
            activeSubTab === 'users' ? 'bg-[#4A6B57] text-white' : 'text-gray-600 hover:bg-gray-100'
          }`}
        >
          <Users className="w-4 h-4" /> Tài khoản người dùng ({profiles.length})
        </button>
      </div>

      {/* ACTIVE SUB TAB CONTENT */}

      {/* 1. STATS TAB */}
      {activeSubTab === 'stats' && (
        <div className="space-y-6 animate-fade-in" id="admin_stats_overview">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-amber-50 p-4 rounded-xl border border-amber-100">
              <span className="text-xs font-bold text-amber-800 uppercase block mb-1">Tổng Học Viên</span>
              <p className="text-2xl font-black text-amber-900">{totalUsers}</p>
              <span className="text-[10px] text-amber-600 font-medium">Bao gồm {adminCount} Admin</span>
            </div>
            
            <div className="bg-indigo-50 p-4 rounded-xl border border-indigo-100">
              <span className="text-xs font-bold text-indigo-800 uppercase block mb-1">Số Bài Học</span>
              <p className="text-2xl font-black text-indigo-900">{totalLessons}</p>
              <span className="text-[10px] text-indigo-600 font-medium">{activeLessons} Đang kích hoạt</span>
            </div>

            <div className="bg-emerald-50 p-4 rounded-xl border border-emerald-100">
              <span className="text-xs font-bold text-emerald-800 uppercase block mb-1">Tổng EXP tích lũy</span>
              <p className="text-2xl font-black text-emerald-900">{totalXP} XP</p>
              <span className="text-[10px] text-emerald-600 font-medium">Hệ thống học viên Dĩ An</span>
            </div>

            <div className="bg-red-50 p-4 rounded-xl border border-red-100">
              <span className="text-xs font-bold text-red-800 uppercase block mb-1">Số Huy Hiệu Treo</span>
              <p className="text-2xl font-black text-red-900">{badges.length}</p>
              <span className="text-[10px] text-red-600 font-medium">Khám phá từng chương</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
            {/* Visual breakdown of Chapter completions */}
            <div className="bg-white p-5 rounded-xl border border-gray-100">
              <h3 className="font-bold text-gray-800 mb-4 text-sm uppercase">Tỷ lệ mở khoá trung bình</h3>
              <div className="space-y-3">
                {chapters.map((ch, i) => (
                  <div key={ch.id} className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="font-semibold text-gray-700 truncate max-w-[80%]">{ch.title}</span>
                      <span className="font-mono text-gray-500">{100 - i * 11}%</span>
                    </div>
                    <div className="w-full bg-gray-100 rounded-full h-2 overflow-hidden">
                      <div className="bg-[#B22222] h-full" style={{ width: `${100 - i * 11}%` }}></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-[#F5F0E6]/20 p-5 rounded-xl border border-amber-100 flex flex-col justify-between">
              <div>
                <h3 className="font-bold text-[#1F2937] mb-2 text-base">Mách nhỏ cho kiểm thử viên (Reviewer) 📝</h3>
                <p className="text-sm text-gray-600 leading-relaxed mb-4">
                  Để trải nghiệm đầy đủ tính mạng game hóa, bạn có thể chuyển sang tab <b>&quot;Tài khoản người dùng&quot;</b> để:
                </p>
                <ul className="text-xs text-gray-600 list-disc list-inside space-y-2 mb-4">
                  <li>Cấp thêm điểm kinh nghiệm nhanh (+100 XP, +500 XP) để thăng hạng.</li>
                  <li>Chuyển đăng nhập giữa Admin và Member.</li>
                  <li>Thay đổi thông tin các khu phố học tập để đua hạng.</li>
                </ul>
              </div>
              <div className="bg-white p-3 rounded-lg border border-amber-100 text-[11px] text-amber-800 italic">
                * Toàn bộ dữ liệu lưu giữ tại LocalStorage nên dữ liệu sẽ không bị xóa nếu đóng tab.
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. CHAPTERS CRUD TAB */}
      {activeSubTab === 'chapters' && (
        <div className="space-y-6 animate-fade-in" id="admin_chapters_crud">
          {/* Chapter Form */}
          <form onSubmit={handleSaveChapter} className="bg-gray-50 p-4 rounded-xl border border-gray-100 space-y-3">
            <h3 className="font-bold text-[#1F2937] text-sm flex items-center gap-1">
              <span>{editingChapterId ? '✏️ Hiệu chỉnh Chương' : '➕ Thêm Chương Mới'}</span>
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <input
                type="text"
                value={chapterForm.title}
                onChange={e => setChapterForm({ ...chapterForm, title: e.target.value })}
                placeholder="Tên chương học (ví dụ: Chương 9: Thế hệ trẻ Dĩ An)"
                className="p-2 border border-gray-200 rounded-lg text-sm bg-white"
                required
              />
              <input
                type="text"
                value={chapterForm.location}
                onChange={e => setChapterForm({ ...chapterForm, location: e.target.value })}
                placeholder="Địa danh biểu trưng (ví dụ: Nghệ An, Dĩ An)"
                className="p-2 border border-gray-200 rounded-lg text-sm bg-white"
                required
              />
              <input
                type="text"
                value={chapterForm.subtitle}
                onChange={e => setChapterForm({ ...chapterForm, subtitle: e.target.value })}
                placeholder="Tiêu đề phụ của chương"
                className="p-2 border border-gray-200 rounded-lg text-sm bg-white"
              />
              <input
                type="text"
                value={chapterForm.cover_image}
                onChange={e => setChapterForm({ ...chapterForm, cover_image: e.target.value })}
                placeholder="URL hình ảnh bìa (để trống sẽ dùng ảnh mặc định)"
                className="p-2 border border-gray-200 rounded-lg text-sm bg-white"
              />
              <textarea
                value={chapterForm.description}
                onChange={e => setChapterForm({ ...chapterForm, description: e.target.value })}
                placeholder="Mô tả tóm tắt nội dung lịch sử cốt lõi của chương"
                className="p-2 border border-gray-200 rounded-lg text-sm bg-white md:col-span-2 h-16"
              />
            </div>

            <div className="flex justify-end gap-2 text-xs pt-1">
              {editingChapterId && (
                <button
                  type="button"
                  onClick={() => {
                    setEditingChapterId(null);
                    setChapterForm({ title: '', subtitle: '', description: '', location: '', cover_image: '' });
                  }}
                  className="px-4 py-2 rounded-lg bg-gray-200 hover:bg-gray-300 font-semibold"
                >
                  Hủy bỏ
                </button>
              )}
              <button
                type="submit"
                className="px-5 py-2 rounded-lg bg-[#4A6B57] hover:bg-[#3d5948] text-white font-bold"
              >
                {editingChapterId ? 'Cập Nhật' : 'Thêm Mới'}
              </button>
            </div>
          </form>

          {/* Chapter Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left text-gray-500 whitespace-nowrap">
              <thead className="text-xs text-gray-700 uppercase bg-gray-100">
                <tr>
                  <th className="px-4 py-3">STT</th>
                  <th className="px-4 py-3">Tên Chương</th>
                  <th className="px-4 py-3">Địa Điểm</th>
                  <th className="px-4 py-3">Mô Tả</th>
                  <th className="px-4 py-3 text-right">Tác vụ</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {chapters.map((ch, idx) => (
                  <tr key={ch.id} className="hover:bg-gray-50">
                    <td className="px-4 py-3 font-semibold text-[#B22222]">{idx + 1}</td>
                    <td className="px-4 py-3 font-bold text-gray-800">{ch.title}</td>
                    <td className="px-4 py-3 text-gray-600">{ch.location}</td>
                    <td className="px-4 py-3 text-gray-400 max-w-xs truncate">{ch.description}</td>
                    <td className="px-4 py-3 text-right space-x-1.5 whitespace-nowrap">
                      <button
                        onClick={() => startEditChapter(ch)}
                        className="p-1.5 text-blue-600 hover:bg-blue-50 rounded"
                        title="Sửa"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteChapter(ch.id)}
                        className="p-1.5 text-red-600 hover:bg-red-50 rounded"
                        title="Xóa"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 3. LESSONS CRUD TAB */}
      {activeSubTab === 'lessons' && (
        <div className="space-y-6 animate-fade-in" id="admin_lessons_crud">
          {/* Lesson Form */}
          <form onSubmit={handleSaveLesson} className="bg-gray-50 p-4 rounded-xl border border-gray-100 space-y-3">
            <h3 className="font-bold text-[#1F2937] text-sm">
              {editingLessonId ? '✏️ Hiệu chỉnh Bài Học' : '➕ Thêm Bài Học Mới'}
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <input
                type="text"
                value={lessonForm.title}
                onChange={e => setLessonForm({ ...lessonForm, title: e.target.value })}
                placeholder="Tên bài học (ví dụ: Chống giặc giặc dốt)"
                className="p-2 border border-gray-200 rounded-lg text-sm bg-white"
                required
              />
              <select
                value={lessonForm.chapter_id}
                onChange={e => setLessonForm({ ...lessonForm, chapter_id: e.target.value })}
                className="p-2 border border-gray-200 rounded-lg text-sm bg-white"
                required
              >
                <option value="">-- Chọn Chương gắn liền --</option>
                {chapters.map(ch => (
                  <option key={ch.id} value={ch.id}>{ch.title}</option>
                ))}
              </select>
              <input
                type="number"
                value={lessonForm.xp_reward}
                onChange={e => setLessonForm({ ...lessonForm, xp_reward: e.target.value })}
                placeholder="Phần thưởng EXP khi thắng bài (mặc định: 20)"
                className="p-2 border border-gray-200 rounded-lg text-sm bg-white"
              />
              <input
                type="text"
                value={lessonForm.description}
                onChange={e => setLessonForm({ ...lessonForm, description: e.target.value })}
                placeholder="Mô tả ngắn gọn về bài này"
                className="p-2 border border-gray-200 rounded-lg text-sm bg-white"
              />
            </div>

            <div className="flex justify-end gap-2 text-xs pt-1">
              {editingLessonId && (
                <button
                  type="button"
                  onClick={() => {
                    setEditingLessonId(null);
                    setLessonForm({ title: '', description: '', chapter_id: '', xp_reward: '20' });
                  }}
                  className="px-4 py-2 rounded-lg bg-gray-200 hover:bg-gray-300 font-semibold"
                >
                  Hủy bỏ
                </button>
              )}
              <button
                type="submit"
                className="px-5 py-2 rounded-lg bg-[#4A6B57] hover:bg-[#3d5948] text-white font-bold"
              >
                {editingLessonId ? 'Cập Nhật' : 'Thêm Bài Học'}
              </button>
            </div>
          </form>

          {/* Lesson Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left text-gray-500 whitespace-nowrap">
              <thead className="text-xs text-gray-700 uppercase bg-gray-100">
                <tr>
                  <th className="px-4 py-3">Tên Bài Học</th>
                  <th className="px-4 py-3">Thuộc Chương</th>
                  <th className="px-4 py-3">Phần thưởng EXP</th>
                  <th className="px-4 py-3 text-right">Tác vụ</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {lessons.map((les) => {
                  const parentCh = chapters.find(c => c.id === les.chapter_id);
                  return (
                    <tr key={les.id} className="hover:bg-gray-50">
                      <td className="px-4 py-3 font-bold text-gray-800">{les.title}</td>
                      <td className="px-4 py-3 text-xs text-[#B22222] font-semibold max-w-xs truncate">
                        {parentCh ? parentCh.title : 'Chưa định nghĩa'}
                      </td>
                      <td className="px-4 py-3 font-mono font-bold text-emerald-600">+{les.xp_reward} EXP</td>
                      <td className="px-4 py-3 text-right space-x-1 whitespace-nowrap">
                        <button
                          onClick={() => startEditLesson(les)}
                          className="p-1.5 text-blue-600 hover:bg-blue-50 rounded"
                          title="Sửa"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteLesson(les.id)}
                          className="p-1.5 text-red-600 hover:bg-red-50 rounded"
                          title="Xóa"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 4. USERS TAB & LOGIN SHORTCUTS */}
      {activeSubTab === 'users' && (
        <div className="space-y-6 animate-fade-in" id="admin_users_moderation">
          <div className="p-4 bg--amber-50 rounded-xl border border-amber-100 flex items-start gap-2 text-xs text-amber-950">
            <ShieldCheck className="w-5 h-5 text-amber-700 flex-shrink-0" />
            <div>
              <p className="font-bold text-sm text-yellow-900">Tính năng Phục vụ Đánh giá (Evaluate Helper)</p>
              <p className="text-gray-600 mt-1">
                Bấm nút <b>&quot;Đăng nhập vai này&quot;</b> để chuyển đổi tức khắc tài khoản đang chơi mà không cần đăng xuất/đăng ký lại. Bạn có thể cộng thẳng +100 XP hoặc +500 XP để nhanh chóng xem huy hiệu mới nhận!
              </p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left text-gray-500 whitespace-nowrap">
              <thead className="text-xs text-gray-700 uppercase bg-gray-100">
                <tr>
                  <th className="px-4 py-3">Họ Tên</th>
                  <th className="px-4 py-3">Vai trò</th>
                  <th className="px-4 py-3">Tích lũy XP</th>
                  <th className="px-4 py-3">Chuỗi ngày</th>
                  <th className="px-4 py-3">Đơn vị / Chi đoàn</th>
                  <th className="px-4 py-3 text-right">Hành động kiểm thử</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {profiles.map(p => (
                  <tr key={p.id} className="hover:bg-gray-50">
                    <td className="px-4 py-3 flex items-center gap-2">
                      <img src={p.avatar_url} alt="avt" className="w-8 h-8 rounded-full border bg-white" />
                      <div>
                        <span className="font-bold text-gray-800 block">{p.full_name}</span>
                        <span className="text-[10px] text-gray-400 font-mono italic">{p.email}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <button 
                        onClick={() => handleToggleAdmin(p.id)}
                        className={`text-[10px] font-extrabold uppercase px-2 py-1 rounded inline-flex items-center gap-1.5 transition-all ${
                          p.role === 'admin' 
                            ? 'bg-red-100 text-[#B22222]' 
                            : 'bg-gray-100 text-gray-600'
                        }`}
                        title="Bấm để đổi vai trò Admin/Member"
                      >
                        {p.role === 'admin' ? '🛡️ Admin' : '👤 Thành viên'}
                      </button>
                    </td>
                    <td className="px-4 py-3 text-emerald-800 font-mono font-bold">
                      {p.xp} XP
                    </td>
                    <td className="px-4 py-3">
                      🔥 <span className="font-bold font-mono">{p.streak_days}</span> ngày
                    </td>
                    <td className="px-4 py-3 font-medium text-gray-600 max-w-xs truncate">
                      {p.unit || 'Chưa cập nhật'}
                    </td>
                    <td className="px-4 py-3 text-right space-x-1">
                      <button
                        onClick={() => handleGiveXP(p.id, 100)}
                        className="px-2 py-1 rounded bg-teal-50 hover:bg-teal-100 text-teal-800 text-xs font-semibold"
                        title="Tặng 100 XP"
                      >
                        +100 XP
                      </button>
                      <button
                        onClick={() => handleGiveXP(p.id, 500)}
                        className="px-2 py-1 rounded bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-semibold"
                        title="Tặng 500 XP"
                      >
                        +500 XP
                      </button>
                      <button
                        onClick={() => onSwitchUser(p.id)}
                        className="px-2.5 py-1 rounded bg-blue-600 hover:bg-blue-700 text-white text-xs font-extrabold"
                      >
                        Đăng nhập vai này
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
