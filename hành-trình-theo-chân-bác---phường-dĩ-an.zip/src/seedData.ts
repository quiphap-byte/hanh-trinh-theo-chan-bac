import { Chapter, Lesson, LessonStep, Badge, Topic } from './types';

export const DEFAULT_TOPICS: Topic[] = [
  {
    id: 'topic-ho-chi-minh-career',
    title: 'Sự nghiệp của Chủ tịch Hồ Chí Minh',
    description: 'Hành trình 79 năm cống hiến vinh quang của Vị Cha già vĩ đại vì sự nghiệp giải phóng dân tộc và thống nhất Tổ quốc.',
    cover_image: 'https://images.unsplash.com/photo-1599707367072-cd6ada2bc375?auto=format&fit=crop&q=80&w=600',
    is_active: true,
    order_index: 1
  }
];

export const DEFAULT_BADGES: Badge[] = [
  {
    id: 'badge-1',
    title: 'Cậu bé xứ Nghệ',
    description: 'Hoàn thành Chương 1: Tuổi thơ sống tại quê hương xứ Nghệ.',
    icon: 'Compass',
    condition_type: 'chapter',
    condition_value: 'chapter-1'
  },
  {
    id: 'badge-2',
    title: 'Người ra đi tìm đường',
    description: 'Hoàn thành Chương 2: Ra đi từ Bến Nhà Rồng tìm con đường cứu nước.',
    icon: 'Anchor',
    condition_type: 'chapter',
    condition_value: 'chapter-2'
  },
  {
    id: 'badge-3',
    title: 'Người chiến sĩ quốc tế',
    description: 'Hoàn thành Chương 3: 30 năm bôn ba qua Pháp, Anh, Mỹ, Liên Xô...',
    icon: 'Globe',
    condition_type: 'chapter',
    condition_value: 'chapter-3'
  },
  {
    id: 'badge-4',
    title: 'Người tìm thấy ánh sáng',
    description: 'Hoàn thành Chương 4: Đọc Luận cương của Lenin, tìm ra con đường giải phóng dân tộc.',
    icon: 'Sparkles',
    condition_type: 'chapter',
    condition_value: 'chapter-4'
  },
  {
    id: 'badge-5',
    title: 'Người trở về',
    description: 'Hoàn thành Chương 5: Trở về Pác Bó trực tiếp chèo lái con thuyền cách mạng.',
    icon: 'MapPin',
    condition_type: 'chapter',
    condition_value: 'chapter-5'
  },
  {
    id: 'badge-6',
    title: 'Mùa thu độc lập',
    description: 'Hoàn thành Chương 6: Khai sinh ra nước Việt Nam Dân chủ Cộng hòa.',
    icon: 'Award',
    condition_type: 'chapter',
    condition_value: 'chapter-6'
  },
  {
    id: 'badge-7',
    title: 'Chủ tịch của nhân dân',
    description: 'Hoàn thành Chương 7: Cùng nhân dân kháng chiến chống Pháp, xây dựng miền Bắc.',
    icon: 'Heart',
    condition_type: 'chapter',
    condition_value: 'chapter-7'
  },
  {
    id: 'badge-8',
    title: 'Dấu chân Người',
    description: 'Hoàn thành Chương 8: Khắc ghi Di chúc và bài học lịch sử thiêng liêng.',
    icon: 'Footprints',
    condition_type: 'chapter',
    condition_value: 'chapter-8'
  }
];

export const DEFAULT_CHAPTERS: Chapter[] = [
  {
    id: 'chapter-1',
    topic_id: 'topic-ho-chi-minh-career',
    title: 'Chương 1: Tuổi trẻ tại quê hương xứ Nghệ',
    subtitle: 'Nghệ An - Quê hương nghĩa nặng tình sâu (1890 - 1909)',
    description: 'Tìm hiểu về quê hương Kim Liên, gia đình hiếu học và bối cảnh lịch sử bồi đắp tư duy yêu nước của Nguyễn Sinh Cung.',
    location: 'Nam Đàn, Nghệ An',
    cover_image: 'https://images.unsplash.com/photo-1621252179027-94459d278660?auto=format&fit=crop&q=80&w=600',
    badge_id: 'badge-1',
    order_index: 1,
    is_active: true
  },
  {
    id: 'chapter-2',
    topic_id: 'topic-ho-chi-minh-career',
    title: 'Chương 2: Người thanh niên tìm đường cứu nước',
    subtitle: 'Khát vọng cứu nước từ Huế vào Sài Gòn (1910 - 1913)',
    description: 'Vượt ngàn dặm Trung Bộ, làm thầy giáo tại Phan Thiết rồi ra khơi tìm đường giải phóng dân tộc từ Bến Nhà Rồng năm 1911.',
    location: 'Sài Gòn - Bến Nhà Rồng',
    cover_image: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&q=80&w=600',
    badge_id: 'badge-2',
    order_index: 2,
    is_active: true
  },
  {
    id: 'chapter-3',
    topic_id: 'topic-ho-chi-minh-career',
    title: 'Chương 3: Ba mươi năm bôn ba thế giới',
    subtitle: 'Năm châu bốn biển - Cuộc sống phong trần (1913 - 1920)',
    description: 'Vượt đại dương lao động vất vả tại Pháp, Anh, Mỹ, thấu hiểu khát vọng tự do và nỗi khổ chung của nhân dân các nước thuộc địa.',
    location: 'Pháp, Anh, Mỹ, Liên Xô',
    cover_image: 'https://images.unsplash.com/photo-1508849789987-4e5333c12b78?auto=format&fit=crop&q=80&w=600',
    badge_id: 'badge-3',
    order_index: 3,
    is_active: true
  },
  {
    id: 'chapter-4',
    topic_id: 'topic-ho-chi-minh-career',
    title: 'Chương 4: Thành lập Đảng Cộng sản Việt Nam',
    subtitle: 'Ánh sáng Luận cương của Lenin (1920 - 1941)',
    description: 'Sáng lập Đảng tại Hương Cảng, vượt qua các gian khó tù đày bí mật rèn luyện lý luận chuẩn bị chèo lái con thuyền Tổ quốc.',
    location: 'Quảng Châu - Hương Cảng',
    cover_image: 'https://images.unsplash.com/photo-1499856138864-7a626d787785?auto=format&fit=crop&q=80&w=600',
    badge_id: 'badge-4',
    order_index: 4,
    is_active: true
  },
  {
    id: 'chapter-5',
    topic_id: 'topic-ho-chi-minh-career',
    title: 'Chương 5: Trở về nước lãnh đạo cách mạng',
    subtitle: 'Hang Pác Bó - Cột mốc lịch sử hồi hương (1941 - 1945)',
    description: 'Trở lại Tổ quốc, dựng xây Mặt trận Việt Minh, xuất bản báo chí cách mạng và thành lập Đội tuyên truyền lực lượng vũ trang anh hùng.',
    location: 'Pác Bó, Cao Bằng',
    cover_image: 'https://images.unsplash.com/photo-1504280390367-361c6d9f38f4?auto=format&fit=crop&q=80&w=600',
    badge_id: 'badge-5',
    order_index: 5,
    is_active: true
  },
  {
    id: 'chapter-6',
    topic_id: 'topic-ho-chi-minh-career',
    title: 'Chương 6: Khai sinh nước Việt Nam mới và kháng chiến',
    subtitle: 'Tuyên ngôn Độc lập ngày 2/9/1945 và trường kỳ kháng chiến (1945 - 1954)',
    description: 'Quảng trường Ba Đình rực rỡ, diệt giặc đói, giặc dốt và lãnh đạo toàn quốc kháng chiến vượt qua vô vàn hy sinh oai hùng chống Pháp.',
    location: 'Ba Đình, Hà Nội',
    cover_image: 'https://images.unsplash.com/photo-1599707367072-cd6ada2bc375?auto=format&fit=crop&q=80&w=600',
    badge_id: 'badge-6',
    order_index: 6,
    is_active: true
  },
  {
    id: 'chapter-7',
    topic_id: 'topic-ho-chi-minh-career',
    title: 'Chương 7: Kháng chiến chống Mỹ và Xây dựng miền Bắc',
    subtitle: 'Kiên cường hậu phương lớn, hướng về miền Nam (1954 - 1968)',
    description: 'Phong cách nếp sống giản dị nhà sàn gỗ, củng cố hậu phương lớn miền Bắc, chi viện hết lòng cho tiền tuyến miền Nam đồng khởi đấu tranh.',
    location: 'Thủ đô Hà Nội',
    cover_image: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&q=80&w=600',
    badge_id: 'badge-7',
    order_index: 7,
    is_active: true
  },
  {
    id: 'chapter-8',
    topic_id: 'topic-ho-chi-minh-career',
    title: 'Chương 8: Di chúc thiêng liêng và di sản trường tồn',
    subtitle: 'Tư tưởng sáng ngời rực rỡ tương lai (1968 - 1969 & Di sản)',
    description: 'Lời răn dạy cuối cùng củng cố lòng đoàn kết dân tộc, bồi dưỡng thanh thế hệ trẻ học tập đức tính cao đẹp viết tiếp tương lai.',
    location: 'Di sản Hồ Chí Minh',
    cover_image: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&q=80&w=600',
    badge_id: 'badge-8',
    order_index: 8,
    is_active: true
  }
];

// 79 lessons meta - 10 per chapter except chapter 8 with 9
const RAW_LESSONS: { chapterId: string; title: string; desc: string; img: string }[] = [
  // Chapter 1 (1-10)
  {
    chapterId: 'chapter-1',
    title: 'Làng Hoàng Trù quê ngoại',
    desc: 'Nơi khai sinh cậu bé Nguyễn Sinh Cung ngày 19/5/1890 trong tình yêu thương ấm áp quê nhà.',
    img: 'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-1',
    title: 'Làng Sen quê nội Nghệ An',
    desc: 'Bối cảnh xóm làng Kim Liên chan chứa nghĩa tình bồi đắp những ký ức mộc mạc thuở ấu thơ.',
    img: 'https://images.unsplash.com/photo-1621252179027-94459d278660?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-1',
    title: 'Thân phụ Nguyễn Sinh Sắc',
    desc: 'Học thức Nho học uyên bác và nhân cách cương trực của Cụ Phó bảng vì dân cứu nước hiên ngang.',
    img: 'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-1',
    title: 'Thân mẫu Hoàng Thị Loan',
    desc: 'Sự tần tảo dệt vải phụ giúp gia đình và những câu hát ru ví dặm thấm ngấm dòng tình yêu quê hương.',
    img: 'https://images.unsplash.com/photo-1511895426328-dc8714191300?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-1',
    title: 'Tình anh chị em ruột thịt',
    desc: 'Tinh thần kiên trinh yêu nước của bà Nguyễn Thị Thanh và ông Nguyễn Sinh Khiêm đồng hành nuôi chí lớn.',
    img: 'https://images.unsplash.com/photo-1517486808906-6ca8b3f04846?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-1',
    title: 'Hành trình ra Kinh đô Huế',
    desc: 'Lần đầu tiên đi xa rời quê hương xứ Nghệ năm 1895, bước chân tiếp cận tri thức kinh đô cổ kính.',
    img: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-1',
    title: 'Nỗi đau mất mẫu thân tại cố đô',
    desc: 'Sự mất mát lớn lao năm 1901 khi thân mẫu Hoàng Thị Loan qua đời giữa lúc Bác mới 11 tuổi đầu.',
    img: 'https://images.unsplash.com/photo-1502005229762-fc1b2381f083?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-1',
    title: 'Tiếp thu nho học bồi vỡ lòng',
    desc: 'Sự rèn luyện Hán học nghiêm cẩn cổ vũ lòng yêu nước sâu sắc từ các bậc thầy trí thức khoa sĩ.',
    img: 'https://images.unsplash.com/photo-1506784983877-45594efa4cbe?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-1',
    title: 'Chí hướng và khát vọng tự lập',
    desc: 'Nỗi bức xúc dồn nén trước cảnh bóc lột của phong kiến đổ nát và dã tâm của thực dân cai trị.',
    img: 'https://images.unsplash.com/photo-1447069387593-a5de0862481e?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-1',
    title: 'Phong trào biểu tình chống thuế',
    desc: 'Hành động dũng cảm năm 1908 của người thanh niên Cung sát cánh bênh vực bảo vệ bà con nông dân nghèo.',
    img: 'https://images.unsplash.com/photo-1454496522488-7a8e488e8606?auto=format&fit=crop&q=80&w=400'
  },

  // Chapter 2 (11-20)
  {
    chapterId: 'chapter-2',
    title: 'Rời Quốc học Huế tìm con đường mới',
    desc: 'Ý chí dứt khoát không chịu học tủ cải cách Pháp để trực tiếp tìm kiếm thực tế sinh tồn cách mạng.',
    img: 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-2',
    title: 'Hành trình vượt ngàn dặm phương Nam',
    desc: 'Rời cố đô xuôi phương Nam tìm cách nhập cục cuộc sống lao động chân lạp của quần chúng.',
    img: 'https://images.unsplash.com/photo-1488646953014-85cb44e25828?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-2',
    title: 'Thầy giáo Nguyễn Tất Thành ở Dục Thanh',
    desc: 'Tiết học nhen nhóm mầm mống yêu nước cho tuổi nhỏ đầy giản dị mộc mạc tại Phan Thiết năm 1910.',
    img: 'https://images.unsplash.com/photo-1497633762265-9d179a990aa6?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-2',
    title: 'Sài Gòn - Sức hút mãnh liệt từ biển khơi',
    desc: 'Cuộc sống vất vả, hòa dòng thác thợ thuyền nghèo khó tại khu vực xóm Chợ Lớn vạn màu sương gió.',
    img: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-2',
    title: 'Sự kiện ngày 5/6/1911 tại Nhà Rồng',
    desc: 'Bước qua lịch sử bước chân hiên ngang ra khơi tìm chân lý chân chính cứu giúp vận mệnh đất nước.',
    img: 'https://images.unsplash.com/photo-1502005229762-fc1b2381f083?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-2',
    title: 'Hồi ức biệt danh phụ bếp Văn Ba',
    desc: 'Nhận việc làm vất vả dọn than gạt xỉ dọn lò sấy của con tàu với nghị lực vô biên thắp sáng.',
    img: 'https://images.unsplash.com/photo-1494412574643-ff11b0a5c1c3?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-2',
    title: 'Sóng bão con tàu buôn Latouche-Tréville',
    desc: 'Hiểm nguy giông tố đại dương, vượt bão biển đen kịt giữ bền gan chí tự học ngoại ngữ thâu đêm.',
    img: 'https://images.unsplash.com/photo-1517411032315-54ef2cb783bb?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-2',
    title: 'Thấu hiểu nỗi lầm than của ba châu lục',
    desc: 'Nhìn nhận ách thực dân dã man chà đạp lên tính mạng người nghèo tại các bến cảng châu Phi và châu Á.',
    img: 'https://images.unsplash.com/photo-1508849789987-4e5333c12b78?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-2',
    title: 'Trực tiếp quan sát nước Mỹ xa xôi',
    desc: 'Thời kỳ làm thuê tại New York, thấu cảm sự tương phản giàu nghèo rõ rệt trong chế độ thuộc bản.',
    img: 'https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-2',
    title: 'Nghị lực quét tuyết mùa đông Luân Đôn',
    desc: 'Vượt giá buốt khắc nghiệt ở Vương quốc Anh, làm nhiều việc tay chân nuôi dưỡng hoài bão cứu quốc.',
    img: 'https://images.unsplash.com/photo-1513635269975-59663e0ca1ad?auto=format&fit=crop&q=80&w=400'
  },

  // Chapter 3 (21-30)
  {
    chapterId: 'chapter-3',
    title: 'Trở lại nước Pháp rực lửa chính trị',
    desc: 'Hòa mình vào phong trào cách mạng công nhân Pháp và giới trí thức tiến bộ xã hội năm 1917.',
    img: 'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-3',
    title: 'Gia nhập lực lượng Đảng Xã hội Pháp',
    desc: 'Dùng diễn đàn của đảng tiến bộ Pháp để lên tiếng tố cáo sự áp bức dã man ở thuộc địa.',
    img: 'https://images.unsplash.com/photo-1499856138864-7a626d787785?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-3',
    title: 'Bản Yêu sách nhân dân An Nam (1919)',
    desc: 'Danh xưng Nguyễn Ái Quốc chấn động dư luận, đòi quyền bình đẳng tối thiểu trước các nguyên thủ.',
    img: 'https://images.unsplash.com/photo-1457369804613-52c61a468e7d?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-3',
    title: 'Sơ thảo luận cương của V.I Lênin',
    desc: 'Bước ngoặt lịch sử năm 1920 khi Bác tìm thấy ánh sáng chân lý cứu quốc duy nhất cho Tổ quốc.',
    img: 'https://images.unsplash.com/photo-1516979187457-637abb4f9353?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-3',
    title: 'Đại hội Tours 1920 quyết định',
    desc: 'Bỏ phiếu sáng lập Đảng Cộng sản Pháp, chuyển từ người yêu nước nồng nàn thành chiến sĩ cộng sản.',
    img: 'https://images.unsplash.com/photo-1504280390367-361c6d9f38f4?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-3',
    title: 'Cơ quan báo đấu tranh Le Paria',
    desc: 'Độc lực xuất bản, viết bài định hình lý luận cách mạng sắc bén đánh thẳng vào lòng sào huyệt thực dân.',
    img: 'https://images.unsplash.com/photo-1504711434969-e33886168f5c?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-3',
    title: 'Vượt sóng sang quê hương cách mạng Liên Xô',
    desc: 'Giai đoạn hoạt động tại đất nước của Cách mạng Tháng Mười rực rỡ từ cuối năm 1923.',
    img: 'https://images.unsplash.com/photo-1512495039889-52a3b799c9bc?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-3',
    title: 'Tham dự Đại hội Quốc tế Cộng sản',
    desc: 'Trực tiếp chất vấn quan điểm sai lầm của các phái tả về vai trò cách mạng giải phóng thuộc địa.',
    img: 'https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-3',
    title: 'Nghẹn ngào tiễn biệt Lênin kính yêu',
    desc: 'Sự ra đi của Lênin năm 1924 và sự kế tục kiên trung tư tưởng giải phóng loài người của Bác.',
    img: 'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-3',
    title: 'Học tập nghiên cứu tại Đại học Phương Đông',
    desc: 'Được rèn luyện và đào tạo nòng cốt chuẩn bị xây dựng lực lượng phong trào vững vàng châu Á.',
    img: 'https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&q=80&w=400'
  },

  // Chapter 4 (31-40)
  {
    chapterId: 'chapter-4',
    title: 'Về Quảng Châu khơi mốc phong trào',
    desc: 'Hành trình áp sát Tổ quốc cuối năm 1924 dưới danh nghĩa cố vấn Borodin tiếng tăm lẫy lừng.',
    img: 'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-4',
    title: 'Huấn luyện cán bộ bồi đắp tài trí',
    desc: 'Trực tiếp mở lớp, rèn dạy lý luận yêu nước cho các thế hệ thanh niên cấp tiến hàng đầu.',
    img: 'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-4',
    title: 'Thành lập Việt Nam Cách mạng Thanh niên',
    desc: 'Tổ chức cách mạng tiền thân, thắp ngọn đuốc tiền phong bùng cháy lòng yêu nước.',
    img: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-4',
    title: 'Báu vật lý luận Đường Kách mệnh',
    desc: 'Cuốn cẩm nang xuất bản năm 1927 tuyên truyền sâu sắc đường lối đấu tranh cách mạng CNXHKH.',
    img: 'https://images.unsplash.com/photo-1516979187457-637abb4f9353?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-4',
    title: 'Hoạt động cách mạng tạo cơ sở tại Xiêm',
    desc: 'Thâm nhập cuộc sống đồng bào kiều bào Thái Lan, định hướng tình cảm hướng về đất mẹ Việt Nam.',
    img: 'https://images.unsplash.com/photo-1508849789987-4e5333c12b78?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-4',
    title: 'Chủ trì thống nhất thành lập Đảng',
    desc: 'Ngày 3/2/1930 tại Hương Cảng thống nhất ba tổ chức, khai sinh ra Đảng Cộng sản Việt Nam độc lực.',
    img: 'https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-4',
    title: 'Tia chớp quật khởi Xô Viết Nghệ Tĩnh',
    desc: 'Định hướng rực sáng phong trào vùng lên của nhân dân đòi phá bỏ xiềng xích thực dân cay nghiệt.',
    img: 'https://images.unsplash.com/photo-1454496522488-7a8e488e8606?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-4',
    title: 'Sự kiện bị bắt giữ bất hợp pháp Hương Cảng',
    desc: 'Nguyễn Ái Quốc bị mật thám Anh giam cầm năm 1931 kiểm thử tinh thần bền chí thép tuyệt vời.',
    img: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-4',
    title: 'Ân đức chí tình của Luật sư Loseby',
    desc: 'Cuộc đấu tranh công lý cao thượng giúp Bác vượt qua nguy hiểm, bảo toàn tính mạng vĩ đại.',
    img: 'https://images.unsplash.com/photo-1505664194779-8bebcb35db72?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-4',
    title: 'Hoạt động bí mật bảo toàn chí cách mạng',
    desc: 'Vượt qua mọi rình rập vây bọc để kiên trì chuẩn bị tiền đề chín muồi cho cách mạng thành công.',
    img: 'https://images.unsplash.com/photo-1488646953014-85cb44e25828?auto=format&fit=crop&q=80&w=400'
  },

  // Chapter 5 (41-50)
  {
    chapterId: 'chapter-5',
    title: 'Vượt mốc 108 trở về nước (1941)',
    desc: 'Thời khắc lịch sử ngày 28/1 xúc động khôn xiết khi Bác đặt chân trở về Tổ quốc thân yêu.',
    img: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-5',
    title: 'Đời sống cách mạng hang Pác Bó',
    desc: 'Bàn đá chông chênh, sáng ra bờ suối, lối sống cách mạng thanh đạm dựng xây nên kỳ tích non sông.',
    img: 'https://images.unsplash.com/photo-1504280390367-361c6d9f38f4?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-5',
    title: 'Đặt danh Suối Lê-nin, Núi Các-Mác',
    desc: 'Gửi gắm triết lý tư tưởng soi đường vào thiên nhiên biên giới Cao Bằng vững chãi anh hùng.',
    img: 'https://images.unsplash.com/photo-1473448912268-2022ce9509d8?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-5',
    title: 'Thành lập Mặt trận Việt Minh oai hùng',
    desc: 'Hội tụ đại đoàn kết lực lượng yêu nước, khơi mào cho phong trào đồng lòng đánh đuổi phát xít Nhật.',
    img: 'https://images.unsplash.com/photo-1506869640319-fe1a24fd76dc?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-5',
    title: 'Ủng hộ xuất bản báo Việt Nam Độc Lập',
    desc: 'Truyền thông cách mạng bằng văn phong giản dị kết nối đồng lòng mọi tầng lớp nhân dân đấu tranh.',
    img: 'https://images.unsplash.com/photo-1504711434969-e33886168f5c?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-5',
    title: 'Gian khổ ngục tù Quảng Tây (1942)',
    desc: 'Bị giam cầm 13 tháng xích xiềng khắc nghiệt qua 18 nhà lao của Tưởng Giới Thạch oai hùng.',
    img: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-5',
    title: 'Báu vật thơ ca Nhật ký trong tù',
    desc: 'Thế giới tinh thần kiên nghị của nhà cách mạng hòa quyện tình yêu thiên nhiên vô hạn tuyệt đẹp.',
    img: 'https://images.unsplash.com/photo-1516979187457-637abb4f9353?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-5',
    title: 'Sáng lập Đội tuyên truyền giải phóng quân',
    desc: 'Ngày 22/12/1944 khởi đầu 34 chiến sĩ, tiền thân oai hùng của Quân đội nhân dân Việt Nam.',
    img: 'https://images.unsplash.com/photo-1506869640319-fe1a24fd76dc?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-5',
    title: 'Căn cứ đầu não Tân Trào lịch sử',
    desc: 'Lán Nà Nưa, mái đình Hồng Thái tập trung chỉ đạo thời cơ chín muồi vùng lên cướp chính quyền.',
    img: 'https://images.unsplash.com/photo-1473448912268-2022ce9509d8?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-5',
    title: 'Quốc dân Đại hội lập chính phủ lâm thời',
    desc: 'Thông qua quốc kỳ, quốc ca thống nhất ý chí triệu dân đứng dậy giành giật sông núi giang sơn.',
    img: 'https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?auto=format&fit=crop&q=80&w=400'
  },

  // Chapter 6 (51-60)
  {
    chapterId: 'chapter-6',
    title: 'Thắng lợi rực rỡ Cách mạng Tháng Tám',
    desc: 'Giành chính quyền độc lập về tay nhân dân toàn quốc tạo nên bước ngoặt thay vai đổi phận.',
    img: 'https://images.unsplash.com/photo-1490730141103-6cac27aaab94?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-6',
    title: 'Sự kiện ngày mùng 2 tháng 9 vĩnh cửu',
    desc: 'Hàng vạn đồng bào hội tụ nín lặng rưng rưng hướng về kỳ đài Ba Đình đón mừng Độc lập.',
    img: 'https://images.unsplash.com/photo-1599707367072-cd6ada2bc375?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-6',
    title: 'Bản Tuyên ngôn Độc lập khai sinh nước Việt',
    desc: 'Những lời văn đanh thép khẳng định chủ quyền, bác bỏ mọi quyền xâm lược bạo ngược.',
    img: 'https://images.unsplash.com/photo-1457369804613-52c61a468e7d?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-6',
    title: 'Phong trào hũ gạo sẻ chia diệt giặc đói',
    desc: 'Bác Hồ đi đầu gương mẫu nhịn ăn sẻ chia hạt cơm nuôi dưỡng bà con thiếu đói khôn lường.',
    img: 'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-6',
    title: 'Phong trào Bình Dân Học Vụ diệt giặc dốt',
    desc: 'Ánh sáng tri thức xóa mù chữ len lỏi khắp vùng thôn quê, nâng cao dân trí chống kẻ thù.',
    img: 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-6',
    title: 'Cuộc Tổng tuyển cử đầu tiên (6/1/1946)',
    desc: 'Ngày hội tự do của toàn thể quốc dân bầu đại biểu Quốc hội chân chính làm chủ chính phủ.',
    img: 'https://images.unsplash.com/photo-1540910419892-4a36d2c3266c?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-6',
    title: 'Ký kết Hiệp định Sơ bộ mềm dẻo khôn khéo',
    desc: 'Chiến thuật ngoại giao sắc bén bẻ lái mọi mưu đồ tiêu diệt sớm chính quyền cách mạng non trẻ.',
    img: 'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-6',
    title: 'Lời hiệu triệu toàn quốc kháng chiến thiêng liêng',
    desc: 'Chiến thư vang vọng ngày 19/12/1946 khẳng định ý chí thép bảo toàn lãnh thổ Tổ quốc.',
    img: 'https://images.unsplash.com/photo-1457369804613-52c61a468e7d?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-6',
    title: 'Lên chiến khu Việt Bắc kháng chiến dài lâu',
    desc: 'Thu hoạch cơ sở quân sự chiến lược vững bền, tạo điểm tựa đập tan dã tâm giặc Pháp.',
    img: 'https://images.unsplash.com/photo-1504280390367-361c6d9f38f4?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-6',
    title: 'Thắng lợi Chiến dịch Biên giới Thu Đông (1950)',
    desc: 'Lần đầu tiên khai thông biên cương tổ quốc tiếp xúc bạn bè quốc tế, thắm tình đồng chí hữu nghị.',
    img: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&q=80&w=400'
  },

  // Chapter 7 (61-70)
  {
    chapterId: 'chapter-7',
    title: 'Trấn oanh chiến dịch Điện Biên Phủ (1954)',
    desc: 'Kỳ tích vang dội năm châu chấn động kết thúc ách đoạt đày thực dân Pháp oai hùng vẻ vang.',
    img: 'https://images.unsplash.com/photo-1599707367072-cd6ada2bc375?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-7',
    title: 'Tiếp quản giải phóng thủ đô Hà Nội',
    desc: 'Chào đón bộ đội trở về, giữ gìn tài sản xã hội, bảo toàn vẻ đẹp cổ kính văn minh tự do.',
    img: 'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-7',
    title: 'Nếp sống mộc mạc thanh ưu tại Nhà Sàn',
    desc: 'Không màng biệt thự tráng lệ, Bác chọn sống nhà sàn gỗ giản dị nuôi hoa chăm cây giữa thủ đô.',
    img: 'https://images.unsplash.com/photo-1582407947304-fd86f028f716?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-7',
    title: 'Huyền thoại Đôi dép cao su hành trình',
    desc: 'Vật dụng đơn sơ đồng hành qua ngàn nẻo đường hành quân gạt bão giông oai vệ kiêu hùng.',
    img: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-7',
    title: 'Tác tác luận thư rèn Đạo Đức Cách Mạng',
    desc: 'Yêu cầu mỗi đảng viên rèn luyện cần kiệm liêm chính chí công vô tư phục vụ Tổ quốc.',
    img: 'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-7',
    title: 'Đồng khởi trỗi dậy anh dũng miền Nam (1960)',
    desc: 'Khơi nguồn phong trào quật cường giúp đồng bào miền Nam đập tan tay sai bạo quyền.',
    img: 'https://images.unsplash.com/photo-1506869640319-fe1a24fd76dc?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-7',
    title: 'Đại hội Đảng toàn quốc lần thứ III lịch sử',
    desc: 'Chiến lược phát triển kiến thiết miền Bắc vững vàng và giải phóng trọn vẹn bờ cõi miền Nam.',
    img: 'https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-7',
    title: 'Xây dựng miền Bắc làm Hậu phương lớn',
    desc: 'Nhà máy, công trường nỗ lực thi đua thắp sáng hậu thuẫn cho tiền tuyến đấu tranh anh dũng.',
    img: 'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-7',
    title: 'Kêu gọi không có gì quý hơn độc lập tự do',
    desc: 'Bản hùng văn chấn động ngày 17/7/1966 thổi bùng hào khí quyết tử bảo vệ non sông.',
    img: 'https://images.unsplash.com/photo-1457369804613-52c61a468e7d?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-7',
    title: 'Cuộc tổng tiến công Tết Mậu Thân (1968)',
    desc: 'Đột kích mưu trí bất ngờ làm xoay chuyển bàn cờ kháng chiến đẩy lùi ý chí giặc Mỹ.',
    img: 'https://images.unsplash.com/photo-1490730141103-6cac27aaab94?auto=format&fit=crop&q=80&w=400'
  },

  // Chapter 8 (71-79)
  {
    chapterId: 'chapter-8',
    title: 'Từng dòng chuẩn bị báu vật Di Chúc',
    desc: 'Chứa chan bao kỳ vọng dành tâm huyết nắn nót sửa chữa từng con chữ từ năm 1965 quý giá.',
    img: 'https://images.unsplash.com/photo-1516979187457-637abb4f9353?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-8',
    title: 'Trời thu Hà Nội nghẹn ngào (2/9/1969)',
    desc: 'Khoảnh khắc đau xót khi trái tim lớn của Người ngừng đập dâng trọn 79 mùa xuân cho non sông.',
    img: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-8',
    title: 'Tang lễ trang trọng tiếc thương khôn nguôi',
    desc: 'Triệu đồng bào nức nở tiễn đưa và sự cảm phục từ bạn bè quốc tế hướng về lãnh tụ kiệt xuất.',
    img: 'https://images.unsplash.com/photo-1599707367072-cd6ada2bc375?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-8',
    title: 'Bài học Tư tưởng đại đoàn kết dân tộc',
    desc: 'Bài ca muôn đời: Đoàn kết, đoàn kết, đại đoàn kết giúp đưa cách mạng vượt ngàn ghềnh thác.',
    img: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-8',
    title: 'Bồi đắp Đạo đức học tập theo chân Bác',
    desc: 'Chuẩn mực sống thanh nhã cần kiệm gần dân không màng bổng lộc mộng tưởng xa hoa.',
    img: 'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-8',
    title: 'Bồi dưỡng thanh niên vừa hồng vừa chuyên',
    desc: 'Lời dặn dò tâm huyết thế hệ trẻ làm nòng cốt đi đầu kiến thiết phục vụ quốc gia.',
    img: 'https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-8',
    title: 'Tư tưởng Hồ Chí Minh - Kim chỉ nam muôn thuở',
    desc: 'Hệ thống lý luận soi đường toàn diện cho mọi thắng lợi vĩ đại của Tổ quốc thời đại mới.',
    img: 'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-8',
    title: 'Tuổi trẻ Dĩ An kiêu hãnh hành trình di sản',
    desc: 'Lực lượng xung kích đoàn viên phường Dĩ An ra sức học tập làm rạng ngời công tác địa phương.',
    img: 'https://images.unsplash.com/photo-1517486808906-6ca8b3f04846?auto=format&fit=crop&q=80&w=400'
  },
  {
    chapterId: 'chapter-8',
    title: 'Tiếp bước quang vinh dựng xây non sông',
    desc: 'Viết tiếp trang sử chói lọi, đưa quê hương Dĩ An vươn mình lên tầm cao thịnh vượng rực rỡ.',
    img: 'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80&w=400'
  }
];

// Map RAW_LESSONS to Lesson format dynamically
export const DEFAULT_LESSONS: Lesson[] = RAW_LESSONS.map((rl, index) => {
  const lessonNumber = index + 1;
  return {
    id: `lesson-${rl.chapterId.split('-')[1]}-${lessonNumber}`,
    chapter_id: rl.chapterId,
    title: `${lessonNumber}. ${rl.title}`,
    description: rl.desc,
    cover_image: rl.img,
    order_index: lessonNumber,
    xp_reward: 20,
    is_active: true
  };
});

// High quality dynamic step generator to ensure ALL 79 lessons function flawlessly!
export const getOrGenerateSteps = (lessonId: string): LessonStep[] => {
  // Try to find the exact lesson details to enrich context
  const lesson = DEFAULT_LESSONS.find(l => l.id === lessonId);
  const title = lesson ? lesson.title : 'Nội dung lịch sử';
  const desc = lesson ? lesson.description : 'Bài học cuộc đời vinh quang của Bác.';
  const coverImg = lesson?.cover_image || 'https://images.unsplash.com/photo-1599707367072-cd6ada2bc375?auto=format&fit=crop&q=80&w=500';

  return [
    {
      id: `step-${lessonId}-s1`,
      lesson_id: lessonId,
      type: 'story',
      title: `Chương lớn: ${title}`,
      content: `Nội dung: ${desc} Cuộc đời sự nghiệp của Chủ tịch Hồ Chí Minh là bản anh hùng ca bất diệt gắn liền với vận mệnh đấu tranh giải phóng dân tộc Việt Nam. Mỗi câu chuyện, cột mốc hiển hách mở ra cho chúng ta những suy ngẫm sâu nặng thiêng liêng về tinh thần quả cảm kiên cường giải phóng quê hương nghèo khó thoát gách đọa đày thực dân dã man.`,
      image_url: coverImg,
      order_index: 1
    },
    {
      id: `step-${lessonId}-s2`,
      lesson_id: lessonId,
      type: 'timeline',
      title: 'Mốc thời gian ghi nhớ',
      fact_year: 'Hành trình Sự Nghiệp',
      fact_location: 'Địa danh lịch sử gắn liền',
      content: `Sự kiện quan trọng rực lửa gắn bó mật thiết với nội dung học tập. Đây là nền tảng hình thành ý chí cách mạng sắt đá gánh vác sứ mệnh cứu quốc vĩ đại.`,
      order_index: 2
    },
    {
      id: `step-${lessonId}-s3`,
      lesson_id: lessonId,
      type: 'true_false',
      title: 'Hỏi nhanh đáp gọn',
      question_text: `Tinh thần nỗ lực thấu cảm khó khăn của Chủ tịch Hồ Chí Minh là bài học đạo đức soi sáng muôn đời cho đoàn viên thế hệ trẻ. Đúng hay Sai?`,
      correct_answer: true,
      explanation: 'Chính xác! Lối sống giản dị gần dân thương đồng bào nghèo của Người là ngọn hải đăng soi đường tự hào học tập suốt đời.',
      points: 5,
      order_index: 3
    },
    {
      id: `step-${lessonId}-s4`,
      lesson_id: lessonId,
      type: 'multiple_choice',
      title: 'Kiểm tra kiến thức',
      question_text: `Chủ đề bài học "${title}" giúp học viên đọng lại thông điệp gì lớn nhất?`,
      options: [
        'Ý chí tự học và rèn luyện vượt mọi giá lạnh',
        'Lòng yêu nước nồng nàn đặt Tổ quốc lên hàng đầu',
        'Phong cách mộc mạc thanh liêm gần gũi thợ thuyền',
        'Tất cả các ý nghĩa tươi đẹp và cao cả ở trên'
      ],
      correct_answer: 3,
      explanation: 'Hoàn toàn chính xác! Bài học hội tụ trọn vẹn mọi khía cạnh chuẩn mực đạo đức và tư tưởng soi sáng chặng đường gấm hoa.',
      points: 5,
      order_index: 4
    }
  ];
};
