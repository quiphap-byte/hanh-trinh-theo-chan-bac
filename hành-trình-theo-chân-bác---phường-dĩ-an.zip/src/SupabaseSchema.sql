-- ==========================================
-- SUPABASE SCHEMA - HÀNH TRÌNH THEO CHÂN BÁC
-- PHƯỜNG DĨ AN - BÌNH DƯƠNG
-- ==========================================

-- Enable UUID generation
create extension if not exists "uuid-ossp";

-- 1. PROFILES Table (Extends Supabase Auth users)
create table public.profiles (
  id uuid primary key references auth.users on delete cascade,
  full_name text not null,
  email text not null,
  avatar_url text,
  unit text, -- khu phố, trường, lớp, đơn vị cán bộ
  role text not null default 'member' check (role in ('admin', 'member', 'guest')),
  xp integer not null default 0,
  streak_days integer not null default 0,
  last_learning_date date,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Row Level Security (RLS) for profiles
alter table public.profiles enable row level security;

-- Profiles Policies
create policy "Allow public read access to profiles for leaderboard"
  on public.profiles for select
  using (true);

create policy "Allow users to update their own profiles"
  on public.profiles for update
  using (auth.uid() = id);

-- 2. BADGES Table
create table public.badges (
  id uuid primary key default uuid_generate_v4(),
  title text not null,
  description text not null,
  icon text not null, -- Lucide icon key or emoji
  condition_type text not null, -- 'chapter'
  condition_value text not null, -- e.g. 'chapter-1'
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

alter table public.badges enable row level security;

create policy "Allow public read access to badges"
  on public.badges for select
  using (true);

create policy "Allow admin full control on badges"
  on public.badges for all
  using (
    exists (
      select 1 from public.profiles
      where id = auth.uid() and role = 'admin'
    )
  );

-- 3. CHAPTERS Table
create table public.chapters (
  id uuid primary key default uuid_generate_v4(),
  title text not null,
  subtitle text,
  description text,
  location text,
  cover_image text,
  badge_id uuid references public.badges(id) on delete set null,
  order_index integer not null,
  is_active boolean not null default true,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

alter table public.chapters enable row level security;

create policy "Allow public read access to active chapters"
  on public.chapters for select
  using (is_active = true);

create policy "Allow admin full control on chapters"
  on public.chapters for all
  using (
    exists (
      select 1 from public.profiles
      where id = auth.uid() and role = 'admin'
    )
  );

-- 4. LESSONS Table
create table public.lessons (
  id uuid primary key default uuid_generate_v4(),
  chapter_id uuid not null references public.chapters(id) on delete cascade,
  title text not null,
  description text,
  cover_image text,
  order_index integer not null,
  xp_reward integer not null default 20,
  is_active boolean not null default true,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

alter table public.lessons enable row level security;

create policy "Allow public read access to active lessons"
  on public.lessons for select
  using (is_active = true);

create policy "Allow admin full control on lessons"
  on public.lessons for all
  using (
    exists (
      select 1 from public.profiles
      where id = auth.uid() and role = 'admin'
    )
  );

-- 5. LESSON_STEPS Table
create table public.lesson_steps (
  id uuid primary key default uuid_generate_v4(),
  lesson_id uuid not null references public.lessons(id) on delete cascade,
  type text not null check (type in ('story', 'timeline', 'multiple_choice', 'true_false', 'matching', 'arrange_timeline')),
  title text not null,
  content text,
  image_url text,
  fact_year text,
  fact_location text,
  order_index integer not null,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

alter table public.lesson_steps enable row level security;

create policy "Allow public read to lesson steps"
  on public.lesson_steps for select
  using (true);

create policy "Allow admin full control on steps"
  on public.lesson_steps for all
  using (
    exists (
      select 1 from public.profiles
      where id = auth.uid() and role = 'admin'
    )
  );

-- 6. QUESTIONS Table
create table public.questions (
  id uuid primary key default uuid_generate_v4(),
  lesson_step_id uuid references public.lesson_steps(id) on delete cascade,
  lesson_id uuid references public.lessons(id) on delete cascade,
  type text not null,
  question_text text not null,
  options jsonb, -- Array of strings
  correct_answer jsonb not null, -- correct index, boolean, or array
  explanation text,
  points integer not null default 5,
  order_index integer not null,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

alter table public.questions enable row level security;

create policy "Allow public read to questions"
  on public.questions for select
  using (true);

create policy "Allow admin full control on questions"
  on public.questions for all
  using (
    exists (
      select 1 from public.profiles
      where id = auth.uid() and role = 'admin'
    )
  );

-- 7. USER_PROGRESS Table
create table public.user_progress (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  lesson_id uuid not null references public.lessons(id) on delete cascade,
  status text not null default 'not_started' check (status in ('not_started', 'completed')),
  score integer not null default 0,
  correct_count integer not null default 0,
  total_questions integer not null default 0,
  completed_at timestamp with time zone,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  unique (user_id, lesson_id)
);

alter table public.user_progress enable row level security;

create policy "Allow progress read to owning user"
  on public.user_progress for select
  using (auth.uid() = user_id);

create policy "Allow progress insert/update to owning user"
  on public.user_progress for all
  using (auth.uid() = user_id);

-- 8. USER_STEP_ANSWERS Table
create table public.user_step_answers (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  lesson_id uuid not null references public.lessons(id) on delete cascade,
  question_id uuid not null references public.questions(id) on delete cascade,
  selected_answer jsonb,
  is_correct boolean not null,
  points_earned integer not null,
  answered_at timestamp with time zone default timezone('utc'::text, now()) not null
);

alter table public.user_step_answers enable row level security;

create policy "Allow user to manage their answers"
  on public.user_step_answers for all
  using (auth.uid() = user_id);

-- 9. USER_BADGES Table
create table public.user_badges (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  badge_id uuid not null references public.badges(id) on delete cascade,
  earned_at timestamp with time zone default timezone('utc'::text, now()) not null,
  unique (user_id, badge_id)
);

alter table public.user_badges enable row level security;

create policy "Allow public read access to earned badges"
  on public.user_badges for select
  using (true);

create policy "Allow user to claim badge"
  on public.user_badges for insert
  with check (auth.uid() = user_id);

-- ==========================================
-- TRIGGERS & FUNCTIONS
-- ==========================================

-- Trigger to automatically create a profile row when a user signs up via auth
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, full_name, email, avatar_url, role, xp, streak_days)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name', 'Học viên kính yêu'),
    new.email,
    coalesce(new.raw_user_meta_data->>'avatar_url', 'https://api.dicebear.com/7.x/adventurer/svg?seed=' || new.email),
    'member',
    0,
    0
  );
  return new;
end;
$$ language plpgsql security definer;

create or replace trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();
