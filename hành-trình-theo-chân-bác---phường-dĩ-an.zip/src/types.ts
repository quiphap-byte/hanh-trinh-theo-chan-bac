/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type UserRole = 'admin' | 'member' | 'guest';

export interface UserProfile {
  id: string;
  full_name: string;
  email: string;
  avatar_url: string;
  unit: string;
  role: UserRole;
  xp: number;
  streak_days: number;
  last_learning_date: string | null; // YYYY-MM-DD
  created_at: string;
}

export interface Badge {
  id: string;
  title: string;
  description: string;
  icon: string; // Lucide icon identifier or emoji
  condition_type: string;
  condition_value: string;
}

export interface Topic {
  id: string;
  title: string;
  description: string;
  cover_image: string;
  is_active: boolean;
  order_index: number;
}

export interface Chapter {
  id: string;
  topic_id: string; // reference to Topic
  title: string;
  subtitle: string;
  description: string;
  location: string;
  cover_image: string;
  badge_id: string;
  order_index: number;
  is_active: boolean;
}

export interface Lesson {
  id: string;
  chapter_id: string;
  title: string;
  description: string;
  cover_image: string;
  order_index: number;
  xp_reward: number;
  is_active: boolean;
}

export type LessonStepType = 
  | 'story' 
  | 'timeline' 
  | 'multiple_choice' 
  | 'true_false' 
  | 'matching' 
  | 'arrange_timeline';

export interface MatchingPair {
  left: string;
  right: string;
}

export interface TimelineItem {
  id: string;
  year: string;
  text: string;
}

export interface LessonStep {
  id: string;
  lesson_id: string;
  type: LessonStepType;
  title: string;
  content?: string;
  image_url?: string;
  fact_year?: string;
  fact_location?: string;
  question_text?: string;
  options?: string[]; // for multiple choice
  correct_answer?: any; // index (number), boolean, or answers array
  explanation?: string;
  points?: number;
  matching_pairs?: MatchingPair[]; // for matching type
  timeline_items?: TimelineItem[]; // for ordering type
  order_index: number;
  created_at?: string;
}

export interface UserProgress {
  id: string;
  user_id: string;
  lesson_id: string;
  status: 'not_started' | 'completed';
  score: number;
  correct_count: number;
  total_questions: number;
  completed_at: string;
}

export interface UserBadge {
  id: string;
  user_id: string;
  badge_id: string;
  earned_at: string;
}

export interface DBState {
  profiles: UserProfile[];
  topics: Topic[];
  chapters: Chapter[];
  lessons: Lesson[];
  lessonSteps: LessonStep[];
  userProgress: UserProgress[];
  badges: Badge[];
  userBadges: UserBadge[];
}
